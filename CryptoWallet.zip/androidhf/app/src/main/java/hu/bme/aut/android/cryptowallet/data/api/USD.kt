package hu.bme.aut.android.cryptowallet.data.api

data class USD(
    val price: Float,
    val percent_change_1h: Float,
    val percent_change_24h: Float,
    val percent_change_7d: Float
)
