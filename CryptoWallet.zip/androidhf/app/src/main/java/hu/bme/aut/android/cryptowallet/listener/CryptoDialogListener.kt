package hu.bme.aut.android.cryptowallet.listener

interface CryptoDialogListener {
        fun onCryptoTraded()
    }