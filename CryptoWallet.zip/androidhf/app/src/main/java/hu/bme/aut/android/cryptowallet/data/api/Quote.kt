package hu.bme.aut.android.cryptowallet.data.api

data class Quote(
    var USD: USD
)
