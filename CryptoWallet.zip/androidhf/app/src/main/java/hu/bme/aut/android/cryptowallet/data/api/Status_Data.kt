package hu.bme.aut.android.cryptowallet.data.api

data class Status_Data(
    val status: Status,
    val data: List<CryptoListItem>
)
